import { base44 } from './base44Client';


export const Plant = base44.entities.Plant;

export const PlantaFormulario = base44.entities.PlantaFormulario;



// auth sdk:
export const User = base44.auth;